#!/usr/env/bin python3
#-*- coding: UTF-8 -*-


import logging
from pathlib import Path
from random import randint

logging.basicConfig(filename="minizinc-python.log", level=logging.DEBUG)
import time
import minizinc
import datetime
from argparse import ArgumentParser, RawTextHelpFormatter
from drawdistinguisher import *
from BAKSHEESHdiff import Diff
#from lin import Lin
import copy
import subprocess
import sys
import atexit

class Logger(object):
    def __init__(self, filename="result.txt", encoding="utf-8"):
        self.terminal = sys.stdout
        self.log = open(filename, "w", encoding=encoding)

    def write(self, message):
        # 保证既输出到终端也写入文件
        try:
            self.terminal.write(message)
        except Exception:
            pass
        try:
            self.log.write(message)
        except Exception:
            pass

    def flush(self):
        try:
            self.terminal.flush()
        except Exception:
            pass
        try:
            self.log.flush()
        except Exception:
            pass

# 将 sys.stdout 重定向到 Logger（print 会同时输出到终端和 result.txt）
sys.stdout = Logger("result.txt")
# 确保程序退出时关闭文件句柄
atexit.register(lambda: getattr(sys.stdout, "log", None) and sys.stdout.log.close())
# ----------------------------------------------------------------


# Check if "OR Tools" appears in the output of "minizinc --solvers" command
try:
    output = subprocess.run(['minizinc', '--solvers'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if "com.google.ortools.sat" in output.stdout.decode("utf-8"):
        ortools_available = True
        print("OR Tools is available")
    else:
        ortools_available = False
        print("OR Tools is not available")
except FileNotFoundError:
    ortools_available = False
    print("OR Tools is not available")


class DiffLin:
    DL_counter = 0

    def __init__(self, param) -> None:
        DiffLin.DL_counter += 1
        self.id = DiffLin.DL_counter
        self.name = "DiffLin" + str(self.id)
        self.type = "DiffLin"
        self.RU = param["RU"]
        self.RM = param["RM"]
        self.RL = param["RL"]
        self.WU = param["WU"]
        self.WM = param["WM"]
        self.WL = param["WL"]
        self.RMU = param["RMU"]
        self.RML = param["RML"]
        self.RD = self.RU + self.RM + self.RL
        self.cp_solver_name = param["solver"]
        ##################################################
        if ortools_available:
            if self.cp_solver_name == "ortools":
                self.cp_solver_name = "com.google.ortools.sat"
        #################################################
        self.cp_solver = minizinc.Solver.lookup(self.cp_solver_name)
        self.time_limit = param["timelimit"]
        self.num_of_threads = param["np"]
        self.mzn_file_name = None
        self.output_file_name = param["output"]
        self.mzn_file_name = "BAKSHEESH-attack.mzn"

    #############################################################################################################################################

    # Search for a distinguisher using MiniZinc

    def search(self):
        """
        Search for a distinguisher
        """

        if self.time_limit != -1:
            time_limit = datetime.timedelta(seconds=self.time_limit)
        else:
            time_limit = None

        start_time = time.time()
        #############################################################################################################################################
        print(f"Searching a distinguisher for {self.RD} rounds of BAKSHEESH ...")
        self.cp_model = minizinc.Model()
        self.cp_model.add_file(self.mzn_file_name)
        self.cp_inst = minizinc.Instance(solver=self.cp_solver, model=self.cp_model)
        self.cp_inst["RU"] = self.RU
        self.cp_inst["RM"] = self.RM
        self.cp_inst["RL"] = self.RL
        self.cp_inst["RMU"] = self.RMU
        self.cp_inst["RML"] = self.RML
        self.cp_inst["WU"] = self.WU
        self.cp_inst["WM"] = self.WM
        self.cp_inst["WL"] = self.WL
        self.cp_inst["offset"] = 0
        self.result = self.cp_inst.solve(timeout=time_limit,
                                         processes=self.num_of_threads,
                                         verbose=False,
                                         debug_output=Path("./debug_output.txt",
                                         intermediate_solutions=True),
                                         random_seed=randint(0, 100),
                                         optimisation_level=2)
        #############################################################################################################################################
        elapsed_time = time.time() - start_time
        print("Time used to find a distinguisher: {:0.02f} seconds".format(elapsed_time))
        print(f"Solver status: {self.result.status}")
        if minizinc.Status.has_solution(self.result.status) or self.result.status == minizinc.Status.ERROR:
            self.attack_summary, self.upper_trail, self.lower_trail = self.parse_solution()
            #diff_effect = self.compute_diff_effect()
            #self.attack_summary = self.attack_summary + f"Diff. effect: 2^({diff_effect})\n"
            print(self.attack_summary)
            draw = DrawDL(self, output_file_name=self.output_file_name)
            draw.generate_distinguisher_shape()
            print("-Log2(P)              ~= \t{:02d}".format(self.result["PU"]))
            print("-Log2(r)              ~= \t{:02d}".format(self.result["CMB"]))
            print("-Log2(Q^2)            ~= \t{:02d}".format(self.result["QL"]))
        elif self.result.status == minizinc.Status.UNSATISFIABLE:
            print("Model is unsatisfiable")
        elif self.result.status == minizinc.Status.UNKNOWN:
            print("Unknown error!")
        else:
            print("Solving process was interrupted")


    #############################################################################################################################################

    # Compute differential effect

    '''def compute_diff_effect(self):
        """
        Compute the differential effect of the differential characteristic
        considering the clustering effect
        """
        time_limit = 10000
        params = {"nrounds" : self.RU,
                  "mode" : 2,
                  "startweight" : 0,
                  "endweight" : 128,
                  "timelimit" : time_limit,
                  "numberoftrails" : 1,
                  "fixedVariables" : {}}

        for bit in range(128):
            params["fixedVariables"][f"x_0_{bit}"] = self.upper_trail["x"][0][bit]
        for bit in range(128):
            params["fixedVariables"][f"x_{self.RU}_{bit}"] = self.upper_trail["x"][self.RU][bit]
        diff = Diff(params)
        diff.make_model()
        diff_effect_upper = diff.solve()
        return diff_effect_upper'''

    #############################################################################################################################################

    # Parse the solution and print the distinguisher's specifications

    def parse_solution(self):
        """
        Parse the solution and print the distinguisher's specifications
        """

        upper_trail = {"x": [[0 for _ in range(128)] for _ in range(self.RU + self.RM + 1)],
                       "y": [[0 for _ in range(128)] for _ in range(self.RU + self.RM)]}
        for r in range(self.RU):
            upper_trail["x"][r] = self.result["xu"][r]
            upper_trail["y"][r] = self.result["yu"][r]
        for r in range(self.RU, self.RU + self.RM + 1):
            upper_trail["x"][r] = self.result["xmu"][r - self.RU]
            if r < self.RU + self.RM:
                upper_trail["y"][r] = self.result["ymu"][r - self.RU]
        lower_trail = {"x": [[0 for _ in range(128)] for _ in range(self.RM + self.RL + 1)],
                       "y": [[0 for _ in range(128)] for _ in range(self.RM + self.RL)]}
        for r in range(self.RM):
            lower_trail["x"][r] = self.result["xml"][r]
            lower_trail["y"][r] = self.result["yml"][r]
        for r in range(self.RM, self.RM + self.RL + 1):
            lower_trail["x"][r] = self.result["xl"][r - self.RM]
            if r < self.RM + self.RL:
                lower_trail["y"][r] = self.result["yl"][r - self.RM]

        def _group_hex32(h32: str) -> str:
            # h32: 32 hex chars
            return " ".join(h32[i:i + 4] for i in range(0, len(h32), 4))

        h = hex(int("".join(map(str, self.result["xu"][0])), 2))[2:].zfill(32)
        input_diff = f"uint128_t inputdiff = 0x{_group_hex32(h)};\n"

        h = hex(int("".join(map(str, self.result["xmu"][0])), 2))[2:].zfill(32)
        input_diff_middle = f"uint128_t inputdiff = 0x{_group_hex32(h)};\n"

        h = hex(int("".join(map(str, self.result["xml"][self.RM])), 2))[2:].zfill(32)
        output_mask_middle = f"uint128_t outputmask = 0x{_group_hex32(h)};\n"

        h = hex(int("".join(map(str, self.result["xl"][self.RL])), 2))[2:].zfill(32)
        output_mask = f"uint128_t outputmask = 0x{_group_hex32(h)};\n"

        attack_summary = "Attack summary:\n"
        attack_summary += f"Setting: RU: {self.RU}, RM: {self.RM}, RL: {self.RL}, RMU: {self.RMU}, RML: {self.RML}, WU: {self.WU}, WM: {self.WM}, WL: {self.WL}\n"
        attack_summary += "#" * 50 + "\n"

        # 只打印一次“输入差分”（首、也可保留上层每轮x的hex：按需）
        attack_summary += "input diff.:\n" + input_diff
        # 如需保留上层每轮x（hex），可以保留；否则删除下面这个循环
        #for r in range(self.RU + 1):
            #attack_summary += hex(int("".join(map(str, upper_trail['x'][r])), 2))[2:].zfill(32) + "\n"

        attack_summary += "#" * 50 + "\n"
        attack_summary += "input diff. middle:\n" + input_diff_middle
        attack_summary += "#" * 50 + "\n"

        # 关键修正：这里不要再追加一堆 lower_trail 的 x
        attack_summary += "output mask middle:\n" + output_mask_middle
        attack_summary += "#" * 50 + "\n"

        # 最终输出掩码——只打印一次
        attack_summary += "output mask:\n" + output_mask
        attack_summary += "#" * 50 + "\n"
        attack_summary += f"PU:  {self.result['PU']}\n"
        attack_summary += f"CMB:  {self.result['CMB']}\n"
        #attack_summary += f"CMW:  {self.result['CMW']}\n"
        attack_summary += f"Q^2: {self.result['QL']}\n"
        #attack_summary += f"Number of effective S-boxes in the middle:       {self.result['CMW']}\n"
        attack_summary += f"Number of effective bit-positions in the middle: {self.result['CMB']}\n"
        attack_summary += "#"*50 + "\n"

        # print the upper trail
        # ---------- 辅助：从多种可能的 state 表示得到 4x32 的 rows ----------
        def _rows_from_state(state):
            """
            输入 state 可以是：
             - 长度为128的 list/iterable（按 bits[0]..bits[127]）
             - 长度为4的 list，每个元素为长度32的 list（每行32位）
             - 其它可迭代，尝试转换
            返回 rows: list of 4 lists (每个 list 包含 32 个字符 '0'/'1'/'-1' 等)
            如果无法解析则抛出 ValueError
            """
            # 如果已经是 4 x 32 的形式
            try:
                s = list(state)
            except Exception:
                raise ValueError("state not iterable")

            # case A: already 4 rows of 32
            if len(s) == 4 and all(hasattr(row, "__len__") and len(row) == 32 for row in s):
                rows = []
                for row in s:
                    # 把每个元素转成字符串（保留 '-1'）
                    rows.append([str(x) for x in row])
                return rows

            # case B: flat 128-length
            if len(s) == 128:
                # construct rows[r][j] = bits[j*4 + r]  (r = 0..3, j = 0..31)
                rows = []
                for r in range(4):
                    row_list = []
                    for j in range(32):
                        val = s[j * 4 + r]
                        row_list.append(str(val))
                    rows.append(row_list)
                return rows

            # case C: maybe nested in other shape (e.g., numpy 1d array)
            # try to flatten recursively to 128
            flat = []

            def _flatten(x):
                try:
                    for el in x:
                        _flatten(el)
                except TypeError:
                    flat.append(x)

            _flatten(s)
            if len(flat) == 128:
                rows = []
                for r in range(4):
                    rows.append([str(flat[j * 4 + r]) for j in range(32)])
                return rows

            raise ValueError(f"cannot interpret state shape (len={len(s)}) as 4x32 or 128-bit")

        #划分割式
        def _normalize_bit(v) -> str:
            # v 可能是 0/1/-1 或字符串 "0"/"1"/"-1"
            if v == -1 or v == "-1":
                return "*"
            s = str(v)
            return "*" if s == "-1" else s  # "0"/"1" 原样返回

        def _group_bits_32(row_list) -> str:
            bitstr = "".join(_normalize_bit(x) for x in row_list)  # 长度应为 32
            return " ".join(bitstr[i:i + 4] for i in range(0, len(bitstr), 4))

        # ---------- 打印 upper trail（使用 rows 视图） ----------
        attack_summary += "Upper trail:\n"
        for r in range(self.RU + self.RM + 1):
            attack_summary += f"Round {r}:\n"
            # x part
            try:
                rows_x = _rows_from_state(upper_trail["x"][r])
                for row in range(4):
                    # join row list -> 32-char string; 把 -1 替换为 '*'
                    #attack_summary += f"x[{row}] = " + "".join(rows_x[row]).replace("-1", "*") + "\n"
                    attack_summary += f"x[{row}] = " + _group_bits_32(rows_x[row]) + "\n"

            except Exception as e:
                attack_summary += f"x: (format error: {e})\n"

            attack_summary += "-" * 50 + "\n"

            # y part, 仅当存在时打印
            if r < len(upper_trail.get("y", [])):
                try:
                    rows_y = _rows_from_state(upper_trail["y"][r])
                    for row in range(4):
                        #attack_summary += f"y[{row}] = " + "".join(rows_y[row]).replace("-1", "*") + "\n"
                        attack_summary += f"y[{row}] = " + _group_bits_32(rows_y[row]) + "\n"
                except Exception as e:
                    attack_summary += f"y: (format error: {e})\n"
            else:
                # 若 upper_trail["y"] 比较短，说明在这个轮没有 y 数据，跳过
                pass

            attack_summary += "#" * 50 + "\n\n"

        # ---------- 打印 lower trail（类似 upper） ----------
        attack_summary += "Lower trail:\n"
        for r in range(self.RM + self.RL + 1):
            attack_summary += f"Round {r}:\n"
            try:
                rows_x = _rows_from_state(lower_trail["x"][r])
                for row in range(4):
                    #attack_summary += f"x[{row}] = " + "".join(rows_x[row]).replace("-1", "*") + "\n"
                    attack_summary += f"x[{row}] = " + _group_bits_32(rows_x[row]) + "\n"

            except Exception as e:
                attack_summary += f"x: (format error: {e})\n"

            attack_summary += "-" * 50 + "\n"

            if r < len(lower_trail.get("y", [])):
                try:
                    rows_y = _rows_from_state(lower_trail["y"][r])
                    for row in range(4):
                        #attack_summary += f"y[{row}] = " + "".join(rows_y[row]).replace("-1", "*") + "\n"
                        attack_summary += f"y[{row}] = " + _group_bits_32(rows_y[row]) + "\n"
                except Exception as e:
                    attack_summary += f"y: (format error: {e})\n"

            attack_summary += "#" * 50 + "\n\n"

        # 最后返回（保持原有返回签名）
        return attack_summary, upper_trail, lower_trail

    # Take the clustering effect for the differential trail into account

    '''def compute_clustering_effect(self):'''

    '''def compute_upper_diff_effect(self):
        """
        Take the clustering effect for the differential trail into account
        """

        print("#" * 50)
        print("Computing the clustering effect for the upper trail ...")
        params_default = {"rounds": self.RU,
                          "ncolumns": self.nc,
                          "mode": 2,
                          "sweight": 0,
                          "endweight": 4 * self.nc,
                          "timelimit": -1,
                          "fixedVariables": {}}

        params = copy.deepcopy(params_default)
        for row in range(4):
            params["fixedVariables"][f"x_0_{row}"] = "".join(list(map(str, self.result["xu"][0][row])))
        for row in range(4):
            params["fixedVariables"][f"x_{self.RU}_{row}"] = "".join(list(map(str, self.result["xu"][self.RU][row])))

        UDiffEffect = Diff(params, exact=True)
        UDiffEffect.make_model()
        udiff_effect = UDiffEffect.solve(log=0)
        return udiff_effect

    def compute_lower_lin_effect(self):
        print("#" * 50)
        print("Computing the clustering effect for the lower trail ...")
        params_default = {"rounds": self.RL,
                          "ncolumns": self.nc,
                          "mode": 2,
                          "sweight": 0,
                          "endweight": 4 * self.nc,
                          "timelimit": -1,
                          "fixedVariables": {}}

        params = copy.deepcopy(params_default)
        for row in range(4):
            params["fixedVariables"][f"x_0_{row}"] = "".join(list(map(str, self.result["xl"][0][row])))
        for row in range(4):
            params["fixedVariables"][f"x_{self.RL}_{row}"] = "".join(list(map(str, self.result["xl"][self.RL][row])))

        LLinEffect = Lin(params, exact=True)
        LLinEffect.make_model()
        llin_effect = LLinEffect.solve(log=0)
        return llin_effect'''

#############################################################################################################################################


def loadparameters(args):
    '''
    Extract parameters from the argument list and input file
    '''

    # Load default values
    params = {"RU": 1,
            "RM": 2,
            "RL": 1,
            "WU": 1,
            "WM": 1,
            "WL": 1,
            "RMU": 0,
            "RML": 0,
            "np" : 8,
            "tl"  : -1,
            "solver"  : "ortools",
            "output"  : "output.tex"}

    # Override parameters if they are set on command line
    if args.RU is not None:
        params["RU"] = args.RU
    if args.RM is not None:
        params["RM"] = args.RM
    if args.RL is not None:
        params["RL"] = args.RL
    if args.WU is not None:
        params["WU"] = args.WU
    if args.WM is not None:
        params["WM"] = args.WM
    if args.WL is not None:
        params["WL"] = args.WL
    if args.RMU is not None:
        params["RMU"] = args.RMU
    if args.RML is not None:
        params["RML"] = args.RML
    if args.np is not None:
        params["np"] = args.np
    if args.timelimit is not None:
        params["timelimit"] = args.timelimit
    if args.solver is not None:
        params["solver"] = args.solver
    if args.output is not None:
        params["output"] = args.output

    return params

def main():
    '''
    Parse the arguments and start the request functionality with the provided
    parameters.
    '''
    #---
    parser = ArgumentParser(description="This tool finds a nearly optimum differential-linear"
                                        "distinguisher for BAKSHEESH block ciphers.",
                            formatter_class=RawTextHelpFormatter)

    parser.add_argument("-RU", type=int, default=5, help="Number of rounds for EU")
    parser.add_argument("-RM", type=int, default=5, help="Number of rounds in the middle")
    parser.add_argument("-RL", type=int, default=5, help="Number of rounds for EL")

    parser.add_argument("-WU", type=int, default=2, help="Weight of EU")
    parser.add_argument("-WM", type=int, default=1, help="Weight of middle")
    parser.add_argument("-WL", type=int, default=2, help="Weight of EL")
    parser.add_argument("-RMU", type=int, default=0, help="Number of rounds passed probabilistically at the beginning of EM")
    parser.add_argument("-RML", type=int, default=0, help="Number of rounds passed probabilistically at the end of EM")
    parser.add_argument("-np", type=int, default=8, help="Number of parallel threads")
    parser.add_argument("-tl", "--timelimit", type=int, default=1000, help="Time limit in seconds")
    parser.add_argument("-sl", "--solver", default="ortools", type=str,
                        choices=['gecode', 'chuffed', 'coin-bc', 'gurobi', 'picat', 'scip', 'choco', 'ortools', 'cplex', 'cbc'],
                        help="choose a cp solver\n")
    parser.add_argument("-o", "--output", default="output.tex", type=str, help="Output file name")

    # Parse command line arguments and construct parameter list

    args = parser.parse_args()
    params = loadparameters(args)
    dld = DiffLin(params)
    dld.search()
    '''udiff_effect = dld.compute_upper_diff_effect()
    llin_effect = dld.compute_lower_lin_effect()
    print(f"Diff effect for upper trail: {udiff_effect}")
    print(f"Lin effect for lower trail: {llin_effect}")'''

if __name__ == "__main__":
    main()
